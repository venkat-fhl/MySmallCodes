var input = document.getElementById("input1");
var ress = document.getElementById("RESULTS");
var scr = document.getElementById("score");
var random = Math.floor(Math.random() * 10) + 1;

var toscr = 10;

function Check() {
  var enterednumber = input.value;
  if (random == enterednumber) {
    console.log("right");

    ress.textContent = "You Are Right";
    alert("YOU FIND CORRECT ANSWER");
  } else {
    toscr= toscr- 1;
    scr.textContent="Score:"+toscr
    console.log("wrong");
    ress.textContent = "You Are Wrong";
  }
}
